ForecastKit
===========

First to use these class's you will need to register for an API key.

https://developer.forecast.io
